# slb-param-registry

SLB 物理层**跨模块参数登记** Skill。  
把分册技术文档里的参数，抽成可共享的真源（SSOT），供 AI / 合作者分模块实现时引用。

**路径**：`.cursor/skills/slb-param-registry/`  
**细则**：见同目录 [`SKILL.md`](./SKILL.md)（Agent 执行步骤与检查清单）。  
**硬依赖**：`nearlink-naming`，且固定 **`airMode=slb`**。

---

## 用途（什么时候用）

| 场景 | 说明 |
|------|------|
| 参数提取 / 登记 | 从技术文档抽 L0–L3，写入共享登记册 |
| 模块实现参数表 | 某子节要列清「输出 / 入参 / 他模块」再 vibecode |
| SessionConfig | L1 字段落成 `SlbPhySessionConfig` 契约 |
| 分册汇总 PDF | 出模块实现参数汇总、分册 L0–L3 四层整合 |
| 对齐 / 改名 | Phase B：draft→frozen、消冲突、过 naming 自检 |

**不用本 Skill**：只写某一节公式详解、无跨模块参数需求 → 用 `slb-doc-generator`。

---

## 和别的 Skill 怎么分

| Skill | 管什么 |
|-------|--------|
| `slb-doc-generator` | 技术文档 / 学习资料骨架 |
| `nearlink-naming` | 工程命名与单位后缀（本 Skill **强制**一起用） |
| **本 Skill** | 参数分层、嵌套引用、登记册、SessionConfig、模块/四层 PDF 规则 |

---

## 核心约定（产出时必须遵守）

1. **四层**：L0 常量 · L1 会话（上层写）· L2 模块可调 · L3 运行时交换  
2. **嵌套**：依赖他模块时**只引其输出**，不展开上游入参  
3. **可读**：节号必须带中文名，如 `6.6.1 角色与汇聚`（LaTeX：`\modref{节号}{中文短名}`）  
4. **命名**：`airMode=slb`；有量纲带 `Hz`/`Us`/`Dbm`/`M` 等后缀  
5. **状态**：`frozen` / `draft` / `tbd`；冲突先改登记册再改代码  

---

## 产出清单

### A. 分册目录（每做一章就出一套）

以 `6.2_*` / `6.5*` / `6.6*` 为例：

| 产物 | 内容 |
|------|------|
| `*参数.txt`（可多份） | 子节详尽 I/O：输出 / 直接入参 / 他模块（节号+中文名+输出名） |
| `*模块实现参数汇总.tex` → `.pdf` | 嵌套模块表，供实现对照 |
| `*参数L0-L3四层整合.tex` → `.pdf` | 本分册去重归层；生产者/消费者/边界带中文名 |

编完 PDF 后清掉 `*.aux *.log *.out *.toc`。

### B. 共享登记册 `参数登记册/`

| 产物 | 内容 |
|------|------|
| `README.md` | 登记册协作背景与目录说明 |
| `SLB物理层L0-L1参数登记册初稿.tex/.pdf` | 全 PHY 常量 + 上层下发会话字段 |
| `SLB物理层SlbPhySessionConfig字段表初稿.tex/.pdf` | L1 → 结构体契约 |
| `SLB物理层L2按模块参数登记册PhaseA粗提.tex/.pdf` | 函数级细模块 + 建议 API |
| `SLB物理层L3跨模块交换登记册.tex/.pdf` | 跨章 L3 生产者/消费者与边界索引 |

分册 PDF 管**细节真源**；`参数登记册/` 管**跨模块合并与所有权**。改一边冲突时：先改分册再回写登记册（或反之经评审）。

---

## 推荐流水线

```
分册技术文档
  → 模块参数.txt（嵌套只引输出；节号+中文名）
  → *模块实现参数汇总.pdf
  → *参数L0-L3四层整合.pdf
  → 合并进 参数登记册/（L0–L1 / L2 / L3 / SessionConfig）
```

Phase A：粗提，标 `draft`/`tbd`。  
Phase B：对齐他章后升 `frozen`，同步 SessionConfig。

---

## 怎么触发（提示词示例）

```
Use slb-param-registry skill together with nearlink-naming. airMode=slb.
Phase A extract from: <分册 tex 路径>
Produce: 模块参数 txt + 模块实现参数汇总 PDF + L0-L3 PDF
Nested: other-module OUTPUTS only; section = number + Chinese title.
Update: 参数登记册/
```

---

## 本目录文件

| 文件 | 给谁看 |
|------|--------|
| `README.md` | 人：用途与产出一览（本文） |
| `SKILL.md` | Agent：完整规则、步骤、检查清单、提示词 |
