---
name: slb-param-registry
description: >-
  Extracts and maintains SLB PHY cross-module parameter registry (L0–L3) and
  SlbPhySessionConfig from technical docs. Always applies nearlink-naming with
  airMode=slb for engineering names. Use when aggregating protocol parameters,
  building param registry, SessionConfig, AI harness constraints, or when
  collaborators need a shared extract-then-refine workflow for vibecoding SLB
  physical layer modules.
---

# SLB 参数登记册 Skill

## 职责

把各分册技术文档中的参数，按统一流程抽成**跨模块参数真源（SSOT）**，供 AI 分模块实现时引用。  
原则：**先粗提、标状态、后对齐修改**——不必等全员终稿。

与现有 Skill 分工：

| Skill | 管什么 |
|-------|--------|
| `slb-doc-generator` | 技术文档/学习资料骨架 |
| `nearlink-naming` | 命名与单位后缀（**本 Skill 强制依赖**） |
| **`slb-param-registry`（本 Skill）** | 参数分层、提取、登记、SessionConfig、迭代规则 |

**硬依赖**：执行本 Skill 时必须同时遵循 `nearlink-naming`，且固定 **`airMode=slb`**。禁止混用 `Sle*` / SLE 术语。登记册里的「工程名」、SessionConfig 字段名、类型名、建议 API 名，一律按 naming Skill 起名；本 Skill 只定分层与所有权，不定第二套命名规则。

---

## 命名硬约束（与 nearlink-naming 一致）

抽取或改写任何参数条目时，工程侧命名必须满足：

### airMode

- 本登记册 / SessionConfig / 相关头文件草稿：**仅** `airMode=slb`
- 类型前缀：`Slb` + `PascalCase`（如 `SlbPhySessionConfig`、`SlbPosRole`）
- 函数前缀：`slb` + `lowerCamelCase`（如 `slbPhySessionValidate`）
- 字段 / 变量：`lowerCamelCase`（如 `localPhyId`、`deltaFHz`）
- L0 常量：`UPPER_SNAKE_CASE`，建议带 `SLB_`（如 `SLB_DELTA_F_HZ`）
- 目录：`nearlink/slb/...`

### 协议术语（禁止自造同义）

使用 SLB 词：`gNode` `tNode` `gLink` `tLink` `sab` `gci` `tci` `pms` `tti` `cot` `dmrsD` `csiRs` `srs` …  
禁止：`masterNode`/`slaveNode`、`downlink`/`uplink`、`syncBlock` 等泛无线替换词。

### 单位后缀（有量纲必须带）

| 量 | 后缀示例 |
|----|----------|
| 频率 | `Hz` / `MHz`（`fsHz`、`deltaFHz`、`centerFreqHz`） |
| 时间 | `Us` / `Ms` / `Ts`（`rfSettleTimeUs`、`superframeDurationUs`、`cpLengthTs`） |
| 功率 | `Dbm` / `Db`（`pMaxDbm`、`srsP0NominalDbm`、`snrDb`） |
| 长度 | `M`（`distanceM`、`anchorXyzM`） |
| 计数/索引 | `Count` / `Index` / `Id`（`subcarrierCount`、`symbolIndex`、`localPhyId`） |

禁止裸名：`freq` `bw` `power` `duration` `len` `id`（无语义前缀时）。

### registry `id` 与工程名对照

| 用途 | 形式 | 示例 |
|------|------|------|
| 稳定 id（文档/合并用） | `slb.<域>.<name>` 点分 | `slb.phy.deltaFHz`、`slb.session.nTti` |
| 工程名（代码字段） | nearlink-naming 的 lowerCamelCase | `deltaFHz`、`nTti` |
| 类型名 | `Slb` + PascalCase | `SlbPhySessionConfig` |

`id` 末段应与工程名一致或可机械映射（如 `slb.session.p0SrsDbm` → `srsP0NominalDbm` 时须在条目中同时写出两者，避免只写符号名）。

### 禁止模糊名

登记册工程名、Session 字段、API 中禁止：`data` `info` `tmp` `flag` `arr` `obj` `val` `res` `ret`。  
短公式符号 `k,l,n,…` 只允许出现在公式说明，不得作为跨模块工程名。

### 交付前 naming 自检（必须做）

与 `nearlink-naming` Self-check 对齐，缺一不可：

1. 已显式 `airMode=slb`，未混入 `Sle*`  
2. 类型 / 函数 / 字段前缀与大小写符合上表  
3. 协议术语为 SLB 词，无自造同义  
4. 一切有量纲工程名带单位后缀  
5. 无模糊名；短变量未进入登记册工程名  
6. 建议 API 动词来自 naming 固定集合（`apply`/`validate`/`calculate`/`estimate`/`generate`/`parse`/`build`/`select`…）

---

## 合作者怎么用（不是每人另发明一套）

**要做**：每个模块负责人（或对应 AI 会话）按本 Skill + `nearlink-naming` 提取**自己分册相关**的参数，合并进共享登记册。  
**不要做**：每人各写一份互不相干的「全局参数表」；不要另定一套字段命名。

| 角色 | 负责提取 |
|------|----------|
| 任意人（首次） | L0 系统常量（全组共用一份，标 `frozen` 后少改） |
| 帧/资源负责人 | L1：`symbolType`、`nTti`、`nCh`/`lCh` 等 |
| 6.5 / 功控调制负责人 | L1：`*P0NominalDbm`、`pMaxDbm`、`mcsIndex`/`modType` |
| 6.6 / 定位负责人 | L1：`localPhyId`、角色、能力位、XRC 已解析子集 |
| 各模块实现时 | 本模块 **L2**；边界上的 **L3** 交换类型 |
| 第 7 章/MAC | 确认 L1 写者字段与已解析结构（可后补） |

合并规则：同一 `id` 只保留一条；冲突时标注，**改登记册再改代码**。工程名冲突时以 `nearlink-naming` 规则裁定。

---

## 四层模型（提取时必须归层）

| 层 | 含义 | 写 | 读 |
|----|------|----|----|
| **L0** | 系统常量（`fsHz`、`deltaFHz`、`subcarrierCount`、光速…） | 无（只读表） | 全 PHY |
| **L1** | 会话/上层下发 → 落入 `SlbPhySessionConfig` | MAC/第7章/调度 | PHY 只读 |
| **L2** | 模块专有可调 | 本模块 | 本模块+边界导出 |
| **L3** | 运行时交换（测量、命令、IE） | 生产者 | 消费者 |

状态：`frozen` | `draft` | `tbd`（文档会改，先 draft 再收紧）。

---

## 两阶段工作流（推荐）

### Phase A — 大方向粗提（先做）

1. 读本模块技术文档：B1 关键参数、允许改变的参数、上下游、接口暴露（若有）。
2. 每条只填最小字段：
   - `id`：`slb.phy.*` / `slb.session.*` / `slb.<module>.*`
   - **工程名**：必须已通过上文「命名硬约束」（nearlink-naming）
   - 单位、归属节号、写者、读者、层（L0–L3）、`status`
3. 输出：更新共享登记册（项目以 `参数登记册/` 为准）。
4. **允许不完整**：未知标 `tbd`，猜测标 `draft`；禁止空着却在代码里写 magic number；禁止用不合规临时名「先占位」而不标 `draft`。

### Phase B — 后期修改对齐（后做）

1. 他章/他人文档到位后，把 `draft`/`tbd` 升为 `frozen` 或合并重名。
2. 改跨模块字段 = 改登记册 + 同步 SessionConfig + 通知消费者。
3. 重命名时同时改 `id` 与工程名，并再跑一遍 naming 自检。
4. 模块内部公式细节可只改分册；**跨模块语义与工程名**必须回写登记册。

---

## 触发场景

- 用户要求：参数汇总、登记册、L0/L1/L2/L3、SessionConfig、参数提取
- 新模块技术文档完成后，要为 vibecode 准备跨模块参数
- 合作者问「我这份文档要抽哪些参数」
- 发现模块间参数冲突、重复常量、或工程名不符合 nearlink-naming

**不触发**：纯写某一节公式详解且无跨模块参数需求（用 `slb-doc-generator`）。

---

## 执行步骤（Agent）

### 0. 绑定命名 Skill（每次必做）

```
airMode = slb
Use nearlink-naming + slb-param-registry together.
```

未声明 airMode 或未按 naming 起名 → **不得**写入登记册工程名列。

### 1. 确认范围

```
- 目标层：L0 / L1 / L2 / L3（新人默认先 L0+本模块相关 L1）
- 来源文档路径
- 输出：参数登记册/ 下 LaTeX+PDF，和/或 SessionConfig
- 合作者角色（本模块 owner）
```

### 2. 抽取

- 优先从「关键参数」「允许改变的参数」「接口维度/暴露」表抽取。
- L1 字段必须能映射到 `SlbPhySessionConfig`。
- XRC：只登记已解析字段，禁止 raw ASN.1。
- 每条工程名当场按「命名硬约束」命名；标准符号（如 $P_o$、$\Delta f$）可写在「符号/说明」列，**不能**代替工程名。

### 3. 写入与状态

- 新 `id`：默认 `draft`；L0 无争议可 `frozen`。
- 与现有 `id` 或工程名冲突：列出冲突表（含 naming 裁定），不静默覆盖。
- 动态当次量（GCI-4 激活、当次子载波数 $M$）→ L3/调用参数，不进 Session 常驻区。

### 4. 交付检查

**内容**

- [ ] 每条有：id、工程名、单位、归属、读写、层、status  
- [ ] L0 无业务模块私建同义常量的建议  
- [ ] L1 无「PHY 自改 MCS/Po」  
- [ ] 注明来源分册路径与日期  
- [ ] 若改 L1：同步 SessionConfig 字段表  

**命名（nearlink-naming）**

- [ ] airMode=slb；无 `Sle*` 混入  
- [ ] 类型 `Slb`+PascalCase；字段 lowerCamelCase；L0 常量 UPPER_SNAKE  
- [ ] 有量纲名带 `Hz`/`Us`/`Dbm`/`M`/`Ts` 等后缀  
- [ ] 无模糊名；协议词为 gNode/tNode/gLink/tLink 等 SLB 术语  
- [ ] `id` 末段与工程名可对照；SessionConfig 字段与登记册工程名一致  

---

## 输出约定

工作区目录：`参数登记册/`

| 产物 | 说明 |
|------|------|
| `README.md` | 背景与协作约定 |
| `SLB物理层L0-L1参数登记册初稿.tex/.pdf` | L0+L1 清单 |
| `SLB物理层SlbPhySessionConfig字段表初稿.tex/.pdf` | L1 → 结构体契约 |

后续可增：`registry.yaml`（机器可读）、各模块 L2 分表。

---

## 快速提示词

```
Use slb-param-registry skill together with nearlink-naming. airMode=slb.
Phase A extract from: <tex path>
Layers: L0 + L1 (related to my module only)
Owner module: <e.g. 6.5.4>
Update: 参数登记册/
Engineering names must pass nearlink-naming self-check (unit suffixes, Slb prefix, no vague names).
Mark unknown as tbd/draft. Do not invent full XRC ASN.1.
```

```
Use slb-param-registry skill together with nearlink-naming. airMode=slb.
Refine Phase B: promote draft→frozen for ids <list>;
align with collaborator doc <path>;
rename any non-compliant engineering names;
sync SessionConfig field table.
```
