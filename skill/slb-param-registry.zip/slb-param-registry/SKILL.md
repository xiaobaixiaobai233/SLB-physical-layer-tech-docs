---
name: slb-param-registry
description: >-
  Extracts and maintains SLB PHY cross-module parameter registry (L0–L3),
  module I/O inventories, and SlbPhySessionConfig from technical docs.
  Enforces nested citation (other-module outputs only), readable section refs
  (number + Chinese title), and nearlink-naming with airMode=slb. Use when
  aggregating protocol parameters, building param registry, SessionConfig,
  module summary / L0–L3 PDFs, AI harness constraints, or shared
  extract-then-refine workflows for vibecoding SLB PHY modules.
---

# SLB 参数登记册 Skill

## 职责

把各分册技术文档中的参数，按统一流程抽成**跨模块参数真源（SSOT）**，并产出：

1. **模块实现参数清单**（txt + 汇总 PDF）：本模块输出 / 直接入参 / 他模块输出；
2. **分册 L0–L3 四层整合 PDF**；
3. **共享登记册**（`参数登记册/`）：L0+L1、L2、L3、SessionConfig。

原则：**先粗提、标状态、后对齐修改**——不必等全员终稿。

与现有 Skill 分工：

| Skill | 管什么 |
|-------|--------|
| `slb-doc-generator` | 技术文档/学习资料骨架 |
| `nearlink-naming` | 命名与单位后缀（**本 Skill 强制依赖**） |
| **`slb-param-registry`（本 Skill）** | 参数分层、提取、嵌套引用、登记、SessionConfig、PDF 产出规则 |

**硬依赖**：执行本 Skill 时必须同时遵循 `nearlink-naming`，且固定 **`airMode=slb`**。禁止混用 `Sle*` / SLE 术语。

---

## 命名硬约束（与 nearlink-naming 一致）

### airMode

- 登记册 / SessionConfig / 相关头文件草稿：**仅** `airMode=slb`
- 类型前缀：`Slb` + `PascalCase`（如 `SlbPhySessionConfig`、`SlbPosRole`）
- 函数前缀：`slb` + `lowerCamelCase`（如 `slbPhySessionValidate`）
- 字段 / 变量：`lowerCamelCase`（如 `localPhyId`、`deltaFHz`）
- L0 常量：`UPPER_SNAKE_CASE`，建议带 `SLB_`（如 `SLB_DELTA_F_HZ`）

### 协议术语（禁止自造同义）

使用 SLB 词：`gNode` `tNode` `gLink` `tLink` `sab` `gci` `tci` `pms` `tti` `cot` `dmrsD` `csiRs` `srs` …  
禁止：`masterNode`/`slaveNode`、`downlink`/`uplink`、`syncBlock` 等泛无线替换词。

### 单位后缀（有量纲必须带）

| 量 | 后缀示例 |
|----|----------|
| 频率 | `Hz` / `MHz` |
| 时间 | `Us` / `Ms` / `Ts` |
| 功率 | `Dbm` / `Db` |
| 长度 | `M` |
| 计数/索引 | `Count` / `Index` / `Id` |

### registry `id` 与工程名

| 用途 | 形式 | 示例 |
|------|------|------|
| 稳定 id | `slb.<域>.<name>` | `slb.phy.deltaFHz`、`slb.rt.distanceM` |
| 工程名 | lowerCamelCase | `deltaFHz`、`distanceM` |
| 类型名 | `Slb` + PascalCase | `SlbPhySessionConfig` |

禁止模糊名：`data` `info` `tmp` `flag` `arr` `obj` `val` `res` `ret`。

---

## 嵌套引用硬约束（他模块）

实现某模块参数表时：

| 允许 | 禁止 |
|------|------|
| 列出本模块**全部**输出与直接入参 | 把上游模块内部入参再抄一遍 |
| 他模块只写：**节号+中文名 + 输出工程名** | 裸节号（如只写 `6.6.1`） |
| 跨章边界表只登记「来源输出 → 本册消费者」 | 在下游展开上游 Gold/`c_init`/CRC 多项式等 |

**示例（正确）**

- AoA 输入：`能力 aoA-Estimation`；`6.6.1 角色与汇聚`；`6.2.3.9 PMS波形`；`6.5.5.8 AoA角度`
- 6.2.3 RS 映射：只引 `6.5.3 伪随机QPSK` → `rsQpskSequence`（不展开 6.5.2 入参）

**LaTeX**

```latex
\newcommand{\modref}[2]{\textit{#1~#2}}
% 用法：\modref{6.6.1}{角色与汇聚}
```

常用短名对照（可按分册增补，须与节标题语义一致）：

| 节号 | 中文短名 |
|------|----------|
| 6.2.2.1 | 波形和符号 |
| 6.2.2.2 | 无线帧和超帧 |
| 6.2.2.3 | COT与TTI |
| 6.2.2.4 | 信道和载波 |
| 6.2.2.7 | 资源元素RE |
| 6.2.3.1 | FTS/STS |
| 6.2.3.9 | PMS波形 |
| 6.2.7 | 3D-FISA |
| 6.2.8 | 多域同步 |
| 6.2.9 | 基带信号生成 |
| 6.5.3 | 伪随机QPSK |
| 6.5.4 | 功率控制 |
| 6.5.5.6–8 | PMS-CSI / PMS时间差 / AoA角度 |
| 6.6.1 | 角色与汇聚 |
| 6.6.2 | 距离测量 |
| 6.6.3.1 | AoA到达角 |
| 6.6.4 | 定位信息解算 |
| 8.3 | 信道中心频率 |

---

## 排版防叠字

- 长 `id` / 工程名：`\ideng{id}{eng}` 上下叠排 + `xurl` `\path`
- 禁止把超长 `\texttt{camelCase}` 塞进窄列导致溢出叠字
- 模块汇总「他模块」列过长时允许换行（`\\`）

---

## 四层模型

| 层 | 含义 | 写 | 读 |
|----|------|----|----|
| **L0** | 系统常量 | 无（只读表） | 全 PHY |
| **L1** | 会话/上层 → `SlbPhySessionConfig` | MAC/第7章/调度 | PHY 只读 |
| **L2** | 模块/函数专有可调 | 本模块 | 本模块+边界 |
| **L3** | 运行时交换 | 生产者 | 消费者 |

状态：`frozen` | `draft` | `tbd`。

---

## 分册产出流水线（Agent 必做顺序）

对给定分册目录（如 `6.2_*` / `6.5*` / `6.6*`）：

### Step A — 模块参数 txt

按子节写清：

- 本模块**输出**（工程名）
- **直接入参**（L0/L1/本地）
- **他模块**：`\modref` 语义（节号+中文名）+ 输出工程名 only

### Step B — 模块实现参数汇总 PDF

- `*模块实现参数汇总.tex` → xelatex 两遍 → PDF
- 约定节写明嵌套规则与 `\modref`
- 清 `*.aux *.log *.out *.toc`

### Step C — 分册 L0–L3 四层整合 PDF

- 从模块清单去重归层
- 生产者/消费者/边界列：**节号+中文名**
- 他章只登记边界输出名，不展开他章内部

### Step D — 回写 `参数登记册/`

- 新/变更 L0·L1 → 更新 L0–L1 册 +（若 L1）SessionConfig 字段表
- 新 L2 细模块 → 更新 L2 Phase A 册
- 跨章 L3 交换 → 更新 `SLB物理层L3跨模块交换登记册`
- 同步 `参数登记册/README.md` 修订记录

冲突：同一 `id` 只留一条；**先改登记册再改代码**；工程名冲突以 `nearlink-naming` 裁定。

---

## 合作者怎么用

| 角色 | 负责提取 |
|------|----------|
| 任意人（首次） | L0 系统常量（全组一份） |
| 帧/资源 | L1：`symbolType`、`nTti`、`nCh`/`lCh`… |
| 6.5 | L1 功控/MCS；模块 I/O + L3 序列/测量 |
| 6.6 | L1 定位会话；模块 I/O + L3 测距/测角/解算 |
| 各模块实现 | 本模块 L2；边界 L3 |
| 第 7 章/MAC | L1 写者字段与已解析结构 |

**不要做**：每人另写互不相干全局表；另定第二套命名；裸节号引用。

---

## 触发场景

- 参数汇总、登记册、L0/L1/L2/L3、SessionConfig、模块 I/O、实现参数 PDF
- 新分册技术文档完成后要为 vibecode 准备跨模块参数
- 可读性：要求「6.x.x 的啥啥啥」而非裸节号
- 模块间参数冲突、重复常量、命名不合规

**不触发**：纯写某一节公式详解且无跨模块参数需求（用 `slb-doc-generator`）。

---

## 执行步骤（Agent）

### 0. 绑定命名

```
airMode = slb
Use nearlink-naming + slb-param-registry together.
```

### 1. 确认范围

```
- 目标层：L0 / L1 / L2 / L3
- 来源文档路径；是否同时出模块汇总 PDF
- 输出：参数登记册/ 和/或 分册 *模块实现参数汇总 / *L0-L3
- 合作者角色（本模块 owner）
```

### 2. 抽取

- 优先：「关键参数」「允许改变的参数」「接口暴露」
- L1 必须能映射到 `SlbPhySessionConfig`
- XRC：只登记已解析字段，禁止 raw ASN.1
- 他模块行：必须「节号+中文名 + 输出」；嵌套不展开上游入参
- 动态当次量（GCI-4、当次 $M$）→ L3，不进 Session 常驻区

### 3. 写入与状态

- 新 `id`：默认 `draft`；L0 无争议可 `frozen`
- 冲突：列出冲突表，不静默覆盖

### 4. 交付检查

**内容**

- [ ] 每条有：id、工程名、单位、归属、读写、层、status  
- [ ] 嵌套：他模块只引输出；无上游入参展开  
- [ ] 节号均带中文短名（`\modref` 或等价）  
- [ ] L0 无业务模块私建同义常量  
- [ ] L1 无「PHY 自改 MCS/Po」  
- [ ] 注明来源分册路径与日期；改 L1 则同步 SessionConfig  

**命名**

- [ ] airMode=slb；无 `Sle*`  
- [ ] 有量纲带单位后缀；无模糊名；SLB 协议词  
- [ ] 建议 API 动词来自 naming 集合  

**排版 / PDF**

- [ ] 长 id 叠排防叠字；xelatex 两遍；中间文件已清  

---

## 输出约定

### `参数登记册/`（共享 SSOT）

| 产物 | 说明 |
|------|------|
| `README.md` | 背景、嵌套规则、协作约定 |
| `SLB物理层L0-L1参数登记册初稿.tex/.pdf` | L0+L1 |
| `SLB物理层SlbPhySessionConfig字段表初稿.tex/.pdf` | L1 → 结构体 |
| `SLB物理层L2按模块参数登记册PhaseA粗提.tex/.pdf` | 函数级 L2 |
| `SLB物理层L3跨模块交换登记册.tex/.pdf` | 跨章 L3 + 边界 |

### 分册目录（细节真源）

| 产物 | 说明 |
|------|------|
| `*参数.txt` | 子节详尽 I/O |
| `*模块实现参数汇总.tex/.pdf` | 嵌套模块表 |
| `*参数L0-L3四层整合.tex/.pdf` | 本分册四层去重 |

后续可增：`registry.yaml`（机器可读）。

---

## 快速提示词

```
Use slb-param-registry skill together with nearlink-naming. airMode=slb.
Phase A extract from: <tex path>
Produce: module param txt + 模块实现参数汇总 PDF + L0-L3 PDF
Nested: cite other-module OUTPUTS only; section refs = number + Chinese title (\modref).
Update: 参数登记册/ (merge L0/L1/L3 as needed)
Mark unknown as tbd/draft. Do not invent full XRC ASN.1.
```

```
Use slb-param-registry skill together with nearlink-naming. airMode=slb.
Refine Phase B: promote draft→frozen for ids <list>;
align with collaborator doc <path>;
fix any bare section numbers to "number + Chinese title";
sync SessionConfig + L3 cross-module registry.
```

```
Use slb-param-registry. Fix readability: replace bare section numbers
in 输入/他模块 and producer/consumer columns with \modref{num}{中文短名}.
Rebuild PDFs and clean aux.
```
