# NearLink Development Naming Prompt

Use this prompt whenever you generate, refactor, review, or test code for NearLink / SparkLink features. Its purpose is to keep AI-generated protocol code consistent, searchable, and easy to maintain.

## Mandatory First Step: Set `airMode`

Before writing code, identify the target `airMode`. It must be exactly one of:

- `slb` for Synchronous Low latency Broadband.
- `sle` for Synchronous Low Energy.
- `common` for code shared by SLB and SLE.

If the user does not specify the target mode, ask a short clarification before making protocol-specific naming decisions.

Apply the mode consistently:

- `airMode=slb`: use `Slb` / `slb` prefixes and SLB terminology.
- `airMode=sle`: use `Sle` / `sle` prefixes and official SLE terminology.
- `airMode=common`: use `NearLink` / `Nl` prefixes and generic NearLink terminology.

Do not mix `Slb*` and `Sle*` protocol prefixes in the same file. If a file truly serves both systems, move or design it as common code and use `NearLink` / `Nl` naming.

## Casing Rules

- Classes, structs, interfaces, enums, and type aliases: `PascalCase`.
- Variables, functions, methods, and object fields: `lowerCamelCase`.
- Constants and compile-time macros: `UPPER_SNAKE_CASE`.
- File names: follow the project language style; prefer `kebab-case` for TypeScript/JavaScript and existing local conventions elsewhere.

Examples:

- SLB types: `SlbGciDecoder`, `SlbResourceGrid`, `SlbTtiScheduler`.
- SLE types: `SleScanner`, `SleAdvertiser`, `SleConnectionManager`.
- Common types: `NearLinkDevice`, `NearLinkAddress`, `NlByteReader`.
- Variables/functions: `gNodeId`, `ttiIndex`, `generateFtsSequence`, `sleConnectionState`, `parseSleAdvReport`.
- Constants: `CENTER_SUBCARRIER_INDEX`, `MAX_RETRY_COUNT`, `DEFAULT_SCAN_TIMEOUT_MS`.

## Protocol Abbreviations

Keep protocol abbreviations in readable lower camel case inside identifiers.

- SLB: `gciBits`, `sabPeriod`, `rabResource`, `dmrsDConfig`, `csiRsConfig`, `ttiIndex`, `cotIndex`.
- SLE: `sleAdvData`, `sleServiceId`, `sleAttributeHandle`, `sleConnectionId`.
- Common/DSP: `crc24b`, `qpskSymbols`, `rxBuffer`, `txBuffer`.

Do not arbitrarily capitalize abbreviations as `GCIBits`, `SABPeriod`, `DMRSDConfig`, or `CSIRSConfig` unless the surrounding language or generated API requires it.

## Terminology Rules

Use the protocol's own vocabulary. Do not invent synonyms for established terms.

For `airMode=slb`, prefer these SLB terms:

`gNode`, `tNode`, `gLink`, `tLink`, `auxLink`, `passthroughLink`, `sab`, `rab`, `gPciB`, `pPciB`, `gci`, `tci`, `dmrsD`, `fts`, `sts`, `srs`, `csiRs`, `pms`, `tti`, `cot`, `resourceGrid`, `resourceElement`, `subcarrier`, `symbol`, `antennaPort`.

Avoid these replacements in SLB code:

- Use `gNode` / `tNode`, not `masterNode` / `slaveNode`.
- Use `gLink` / `tLink`, not generic `downlink` / `uplink` when the SLB term is intended.
- Use `sab` / `rab`, not vague `syncBlock` / `accessBlock`.
- Use the exact signal name such as `dmrsD`, `csiRs`, or `srs`, not generic `pilotSignal`.

For `airMode=sle`, use official SLE specification or SDK names. Do not force SLB terms such as `gNode`, `tNode`, `gLink`, or `tLink` into SLE code.

Common upper-layer terms may be used only for shared code:

`nearLinkDevice`, `localDevice`, `remoteDevice`, `connection`, `packet`, `frame`, `payload`, `service`, `securityContext`.

## Semantic Suffixes

Use suffixes consistently:

- `Id`: stable identifier, such as `gNodeId`.
- `Index`: zero-based position, such as `symbolIndex`.
- `Count`: number of items, such as `portCount`.
- `Length`: logical length, with units when relevant, such as `payloadLengthBytes`.
- `Offset`: relative position, such as `ttiOffset`.
- `Period`: periodic interval, such as `sabPeriodMs`.
- `Mask`: bit mask, such as `crcMask`.
- `Bitmap`: packed set of flags or resources, such as `gciGroupBitmap`.
- `Config`: input configuration, such as `srsConfig`.
- `Result`: operation output, such as `decodeResult`.
- `Context`: state carried across operations, such as `rxContext`.
- `Buffer`: byte or sample storage, such as `rxBuffer`.

## Units

Every variable with a physical or protocol unit must include that unit in the name:

`centerFreqHz`, `bandwidthMHz`, `sampleRateHz`, `symbolDurationUs`, `cpLengthTs`, `txPowerDbm`, `rssiDbm`, `snrDb`, `freqOffsetPpm`, `timeoutMs`, `payloadLengthBytes`.

Avoid bare names such as `freq`, `bw`, `power`, `duration`, or `len` in public APIs, struct fields, and cross-function parameters.

## Formula Variables

Short variables such as `k`, `l`, `n`, `p`, `i`, `j`, `r`, `u`, and `v` are allowed only inside small formula-aligned functions or tight loops near the formula they implement.

Do not expose short variables as function parameters, struct fields, class members, or long-range state. Use semantic names instead:

`subcarrierIndex`, `symbolIndex`, `antennaPort`, `sequenceIndex`, `frameIndex`, `bitIndex`.

## Function Verbs

Use a stable verb vocabulary:

- `generate` for sequences or signals.
- `map` for placement onto a grid or resource structure.
- `encode` / `decode` for structure-to-bits and bits-to-structure transforms.
- `parse` / `build` for bytes-to-structure and structure-to-bytes transforms.
- `calculate` for deterministic formulas.
- `estimate` for values inferred from a signal.
- `detect` for events, peaks, candidates, or presence decisions.
- `validate` for checks that return validity or diagnostics.
- `scramble` / `descramble` for scrambling transforms.
- `schedule` for resource allocation.
- `select` for choosing a mode, index, candidate, or configuration.

Examples:

`generateFtsSequence`, `decodeGciBits`, `parseSabInfo`, `buildSleAdvData`, `calculateCrc24b`, `estimateFrequencyOffset`, `detectSabCandidate`, `validateCrc24b`, `scheduleGLinkResource`, `selectMcsIndex`.

## Vague Names

Do not use vague names when the scope is longer than five lines:

`data`, `info`, `tmp`, `flag`, `arr`, `obj`, `val`, `res`, `ret`, `foo`, `bar`.

Use concrete names instead:

`gciBits`, `sabInfo`, `decodeResult`, `payloadBytes`, `isCrcValid`, `candidateTtiIndex`.

## Review Checklist

Before returning code, check:

1. The target `airMode` is explicit: `slb`, `sle`, or `common`.
2. Protocol prefixes match the selected mode.
3. `Slb*` and `Sle*` prefixes are not mixed in one file.
4. SLB terms are not applied to SLE code.
5. Shared code uses `NearLink` / `Nl`, not protocol-specific prefixes.
6. Unit-bearing variables include units.
7. Short formula variables are local and close to the formula.
8. Function names use the approved verb vocabulary.
9. Vague names have been replaced unless their scope is tiny.

## Prompt Snippets

Use one of these at the start of a coding request:

```text
Use the NearLink naming prompt. airMode=slb. Follow the naming rules and run the review checklist before returning code.
```

```text
Use the NearLink naming prompt. airMode=sle. Do not use SLB-specific terms.
```

```text
Use the NearLink naming prompt. airMode=common. Keep all shared code under NearLink/Nl naming.
```
