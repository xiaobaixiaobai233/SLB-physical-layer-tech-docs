---
name: nearlink-naming
description: Naming conventions for 星闪 / NearLink (SLB / SLE) code. Use whenever the task involves NearLink protocol, algorithm, driver, SDK, parser, encoder/decoder, scheduler, PHY/MAC/data-link implementation, or related tests — especially during vibecoding, to keep AI-generated names predictable and consistent.
---

# NearLink Naming Conventions

## Step 0: Decide the airMode first (most important)

Before writing any code, fix the `airMode` for the task. Pick exactly one:

- `slb` — Synchronous Low latency Broadband
- `sle` — Synchronous Low Energy
- `common` — code shared by both SLB and SLE

**Never phrase it as "SLB or SLE".** Each file, each block follows the current airMode only. Never mix `Slb*` and `Sle*` in the same file.

> SLB and SLE are two separate systems. SLB-specific terms (gNode, tNode, SAB, DMRS-D, …) must **not** be applied to SLE.

## Prefixes

| airMode | Type/Class prefix | Variable/function prefix | Directory |
|---|---|---|---|
| slb | `Slb` | `slb` or SLB terms | `nearlink/slb` |
| sle | `Sle` | `sle` or SLE terms | `nearlink/sle` |
| common | `NearLink` / `Nl` | `nearLink` / `nl` | `nearlink/common` |

```ts
class SlbGciDecoder {}        // slb
class SleAdvertiser {}        // sle
class NearLinkDevice {}       // common
class NlByteReader {}         // common
```

## Casing

TypeScript-style by default (defer to the target language when it requires otherwise):

- Classes / types / enums: `PascalCase`
- Variables / functions / methods: `lowerCamelCase`
- Constants: `UPPER_SNAKE_CASE`
- File names: `kebab-case`
- Protocol fields: `lowerCamelCase`

```ts
const gNodeId = syncInfo.gNodeId
const dmrsDConfig = parseDmrsDConfig(bits)
const DEFAULT_SCAN_TIMEOUT_MS = 3000
```

## Protocol terminology (follow the airMode; do not invent synonyms)

**airMode = slb** — use SLB terms directly; do not replace them with generic wireless words:

`gNode` `tNode` `gLink` `tLink` `auxLink` `passthroughLink` `sab` `rab` `gPciB` `pPciB` `gci` `tci` `fts` `sts` `srs` `csiRs` `dmrsD` `pms` `tti` `cot` `resourceGrid` `resourceElement` `subcarrier` `symbol` `antennaPort`

| Avoid | Use |
|---|---|
| masterNode / slaveNode | gNode / tNode |
| downlink / uplink | gLink / tLink |
| syncBlock / accessBlock | sab / rab |
| pilotSignal | dmrsD / csiRs / srs |

**airMode = sle** — prefer the official terms from the SLE spec or SDK; **never** force gNode/tNode/gLink/tLink onto SLE. Generic examples:

`sleDevice` `sleAddress` `sleAdvertiser` `sleScanner` `sleConnection` `sleConnectionId` `sleService` `sleAttribute` `sleAttributeHandle` `sleAdvData` `slePairing` `sleSecurityContext`

**airMode = common** — use `NearLink` / `Nl` for shared upper-layer concepts:

`nearLinkDevice` `localDevice` `remoteDevice` `connection` `packet` `frame` `payload` `service` `securityContext`

## Semantic suffixes

`Id` (gNodeId) · `Index` (symbolIndex, zero-based) · `Count` (portCount) · `Length` (payloadLengthBytes) · `Offset` (ttiOffset) · `Period` (sabPeriodMs) · `Mask` (crcMask) · `Bitmap` (gciGroupBitmap) · `Config` (srsConfig) · `Result` (decodeResult) · `Context` (rxContext) · `Buffer` (rxBuffer)

## Units

Any variable with a physical unit must carry the unit suffix:

`centerFreqHz` `bandwidthMHz` `sampleRateHz` `symbolDurationUs` `cpLengthTs` `txPowerDbm` `rssiDbm` `snrDb` `freqOffsetPpm` `timeoutMs` `payloadLengthBytes`

No bare names: `freq` `bw` `power` `duration` `len`.

## Short formula variables

Short names `k l n p i j r u v` are allowed **only** inside short formula-aligned functions. Cross-function parameters, struct fields, and public APIs must use semantic names (`subcarrierIndex` `symbolIndex` `antennaPort` `sequenceIndex` …).

```ts
// Good
function mapFtsToResourceGrid(grid: SlbResourceGrid, fts: Complex[], symbolIndex: number) {
  for (let k = 0; k < SUBCARRIER_COUNT; k++) grid.set(k, symbolIndex, fts[k])
}
// Bad
function mapFts(g, d, l, p) {}
```

## Function verbs (fixed set)

`generate` (sequence/signal) · `map` (onto resource grid) · `encode` / `decode` (struct ↔ encoded bits) · `parse` / `build` (bytes ↔ struct) · `calculate` (deterministic formula) · `estimate` (from a signal) · `detect` (signal/event) · `validate` · `scramble` / `descramble` · `schedule` (resource allocation) · `select` (mode/index)

```ts
generateFtsSequence()  decodeGciBits()  parseSabInfo()  estimateFrequencyOffset()
validateCrc24b()  scheduleGLinkResource()  selectMcsIndex()
```

## Forbidden vague names

Banned when the scope is longer than 5 lines: `data info tmp flag arr obj val res ret foo bar`.
Use concrete names instead: `gciBits` `sabInfo` `decodeResult` `payloadBytes` `isCrcValid`.

## Self-check before returning code

1. Is the airMode explicit (slb / sle / common)?
2. Are `Slb` / `Sle` / `NearLink` prefixes consistent, with no mixing in one file?
3. Are protocol terms taken from the correct airMode?
4. Do all unit-bearing variables carry their unit?
5. Are short formula variables confined to local formula code?
6. Are function verbs from the fixed set? Are vague names removed?

---

**Usage** (once it's in the repo, one line in the prompt is enough):

> Use the nearlink-naming skill for this task. airMode=slb. Follow the skill and self-check naming before returning code.

> Use the nearlink-naming skill for this task. airMode=sle. Do not use SLB-specific terms.