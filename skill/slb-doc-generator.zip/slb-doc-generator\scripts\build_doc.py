#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build SLB LaTeX document: xelatex x2, cleanup aux files.

Usage:
    python build_doc.py <path/to/document.tex>
    python build_doc.py <path/to/document.tex> --keep-aux
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys

AUX_EXT = (".aux", ".log", ".out", ".toc", ".synctex.gz", ".fls", ".fdb_latexmk")


def compile_tex(tex_path: str, keep_aux: bool = False) -> int:
    tex_path = os.path.abspath(tex_path)
    if not os.path.isfile(tex_path):
        print(f"ERROR: file not found: {tex_path}", file=sys.stderr)
        return 1

    work_dir = os.path.dirname(tex_path)
    tex_name = os.path.basename(tex_path)
    base = os.path.splitext(tex_name)[0]

    print(f"Building: {tex_path}")

    for run in (1, 2):
        result = subprocess.run(
            ["xelatex", "-interaction=nonstopmode", tex_name],
            cwd=work_dir,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if result.returncode != 0:
            print(f"ERROR: xelatex run {run} failed (exit {result.returncode})", file=sys.stderr)
            combined = (result.stdout or "") + (result.stderr or "")
            lines = combined.strip().splitlines()
            for line in lines[-40:]:
                print(line, file=sys.stderr)
            return result.returncode
        print(f"  xelatex pass {run}/2 OK")

    pdf_path = os.path.join(work_dir, base + ".pdf")
    if os.path.isfile(pdf_path):
        print(f"PDF: {pdf_path} ({os.path.getsize(pdf_path)} bytes)")
    else:
        print("ERROR: PDF not generated", file=sys.stderr)
        return 1

    if not keep_aux:
        removed = 0
        for ext in AUX_EXT:
            aux = os.path.join(work_dir, base + ext)
            if os.path.isfile(aux):
                os.remove(aux)
                removed += 1
        print(f"Cleaned {removed} auxiliary file(s)")

    print("BUILD OK")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Build SLB LaTeX document")
    parser.add_argument("tex_file", help="Path to .tex file")
    parser.add_argument("--keep-aux", action="store_true", help="Keep auxiliary files")
    args = parser.parse_args()
    return compile_tex(args.tex_file, keep_aux=args.keep_aux)


if __name__ == "__main__":
    sys.exit(main())
