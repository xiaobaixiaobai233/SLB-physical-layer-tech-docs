#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate SLB learning material structure.

Usage:
    python validate_learning_doc.py <path/to/learning.tex>
"""

from __future__ import annotations

import re
import sys


REQUIRED_CHECKS = [
    ("xelatex header", r"% !TEX program = xelatex"),
    ("ctexart documentclass", r"\\documentclass.*\{ctexart\}"),
    ("T/XS standard ref", r"T/XS 10001-2025"),
    ("20250326 version", r"20250326"),
    ("learning material marker", r"学习资料"),
    ("disclaimer footer", r"仅供理解参考|仅供理解/教学参考"),
]

FORBIDDEN_CHECKS = [
    ("no Part 1 总览", r"\\part\{总览\}"),
    ("no 模块边界 section", r"\\section\{模块边界"),
    ("no 协议章节对应", r"\\section\{协议章节对应\}"),
    ("no 约束与实现要点", r"\\section\{约束与实现要点\}"),
    ("no engineering Step format", r"\\textbf\{Step \d+\}"),
    ("no floating table env", r"\\begin\{table\}"),
]

TEACHING_CHECKS = [
    ("learn macro or keypoint", r"\\learn\{|\\begin\{keypoint\}"),
]


def _check_table_rules(text: str, errors: list[str], warnings: list[str]) -> None:
    """Enforce longtable + caption + no handwritten 表 N in captions."""
    if re.search(r"\\begin\{longtable\}", text) and not re.search(
        r"\\usepackage\{longtable\}", text
    ):
        errors.append("MISSING: \\usepackage{longtable} required when using longtable")

    for i, m in enumerate(
        re.finditer(r"\\begin\{longtable\}.*?\\end\{longtable\}", text, re.DOTALL), 1
    ):
        if "\\caption{" not in m.group(0):
            errors.append(
                f"MISSING: longtable #{i} has no \\caption "
                "(every table must be captioned for sequential numbering)"
            )

    if re.search(r"\\caption\{\s*表\s*\d+", text):
        errors.append(
            "FORBIDDEN: \\caption starts with handwritten 「表 N」 "
            "(causes double numbering); use descriptive title only"
        )


def validate(path: str) -> tuple[list[str], list[str]]:
    with open(path, encoding="utf-8") as f:
        text = f.read()

    errors: list[str] = []
    warnings: list[str] = []

    for name, pattern in REQUIRED_CHECKS:
        if not re.search(pattern, text):
            errors.append(f"MISSING: {name}")

    for name, pattern in FORBIDDEN_CHECKS:
        if re.search(pattern, text):
            errors.append(f"FORBIDDEN: {name}")

    _check_table_rules(text, errors, warnings)

    has_teaching = any(re.search(p, text) for _, p in TEACHING_CHECKS)
    if not has_teaching:
        warnings.append("WARN: no \\learn{} or keypoint environment found (recommend >= 3)")

    learn_count = len(re.findall(r"\\learn\{", text))
    keypoint_count = len(re.findall(r"\\begin\{keypoint\}", text))
    total = learn_count + keypoint_count
    if total < 3:
        warnings.append(f"WARN: only {total} learning highlight(s), recommend >= 3")

    if not re.search(r"直观理解|记忆口诀|导读|整体图景", text):
        warnings.append("WARN: no 直观理解/记忆口诀/导读/整体图景 found")

    if not re.search(r"\\section\{", text):
        errors.append("MISSING: no \\section{} found")

    return errors, warnings


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python validate_learning_doc.py <learning.tex>", file=sys.stderr)
        return 2

    path = sys.argv[1]
    errors, warnings = validate(path)

    print(f"Validating learning material: {path}")
    for w in warnings:
        print(f"  {w}")
    for e in errors:
        print(f"  {e}")

    if errors:
        print(f"FAILED: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1

    print(f"PASSED: {len(warnings)} warning(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
