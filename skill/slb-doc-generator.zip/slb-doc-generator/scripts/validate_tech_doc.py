#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate SLB technical document structure.

Usage:
    python validate_tech_doc.py <path/to/tech-doc.tex>
"""

from __future__ import annotations

import re
import sys


REQUIRED_CHECKS = [
    ("xelatex header", r"% !TEX program = xelatex"),
    ("ctexart documentclass", r"\\documentclass.*\{ctexart\}"),
    ("Part 1 总览", r"\\part\{总览\}"),
    ("协议章节对应", r"\\section\{协议章节对应\}"),
    ("功能定义", r"\\section\{功能定义\}"),
    ("模块边界", r"\\section\{模块边界"),
    ("SLB 通信流程角色", r"\\section\{在 SLB 通信流程中的角色\}"),
    ("关键参数", r"\\section\{关键参数"),
    ("约束与实现要点", r"\\section\{约束与实现要点\}"),
    ("章节衔接", r"\\section\{与标准其他章节的衔接\}"),
    ("T/XS standard ref", r"T/XS 10001-2025"),
    ("20250326 version", r"20250326"),
]

FORBIDDEN_CHECKS = [
    ("no \\learn{} macro", r"\\learn\{"),
    ("no 记忆口诀", r"记忆口诀"),
    ("no 直观理解 table header", r"直观理解"),
    ("no 学习资料 marker", r"—— 学习资料 ——"),
    ("no floating table env", r"\\begin\{table\}"),
]

OPTIONAL_WARNINGS = [
    ("upstream table", r"\\subsection\{上游模块\}"),
    ("downstream table", r"\\subsection\{下游模块\}"),
    ("processing steps", r"\\section\{处理步骤\}"),
    ("core detail section", r"\\section\{.*核心详解\}"),
]


def _check_table_rules(text: str, errors: list[str], warnings: list[str]) -> None:
    """Enforce longtable + caption + sequential auto-numbering rules."""
    if re.search(r"\\begin\{longtable\}", text) and not re.search(
        r"\\usepackage\{longtable\}", text
    ):
        errors.append("MISSING: \\usepackage{longtable} required when using longtable")

    if re.search(r"\\begin\{tabular\}", text) and not re.search(
        r"\\begin\{longtable\}", text
    ):
        # bare tabular outside longtable is discouraged when used as content tables
        warnings.append(
            "WARN: bare tabular found; prefer longtable with \\caption for content tables"
        )

    for i, m in enumerate(
        re.finditer(r"\\begin\{longtable\}.*?\\end\{longtable\}", text, re.DOTALL), 1
    ):
        block = m.group(0)
        if "\\caption{" not in block:
            errors.append(
                f"MISSING: longtable #{i} has no \\caption "
                "(every table must be captioned for sequential numbering)"
            )

    # Caption must not start with handwritten 表 N (double numbering with auto counter)
    if re.search(r"\\caption\{\s*表\s*\d+", text):
        errors.append(
            "FORBIDDEN: \\caption starts with handwritten 「表 N」 "
            "(causes double numbering like 「表 8: 表 2 …」); "
            "use descriptive title only, let LaTeX auto-number"
        )


def _extract_constraints_section(text: str) -> str | None:
    match = re.search(
        r"\\section\{约束与实现要点\}(.*?)(?:\\section\{|\\end\{document\})",
        text,
        re.DOTALL,
    )
    return match.group(1) if match else None


def count_constraints(text: str) -> int:
    """Count constraints in 约束与实现要点 flexibly.

    Accepted formats (any combination):
    - \\item \\textbf{【主题】}：...
    - \\item 【主题】：...
    - \\item \\textbf{Topic}：...  (no brackets)
    - Plain lines starting with 【主题】：
    - Numbered list without \\item (rare; counted via 【】 markers)
    """
    body = _extract_constraints_section(text)
    if not body:
        return 0

    item_count = len(re.findall(r"\\item\b", body))
    bracket_count = len(re.findall(r"【[^】]+】", body))
    standalone_lines = len(re.findall(r"^\s*【[^】]+】", body, re.MULTILINE))

    # Prefer explicit list items when present; otherwise themed bracket lines.
    if item_count > 0:
        return max(item_count, bracket_count)
    return max(bracket_count, standalone_lines)


def validate(path: str) -> tuple[list[str], list[str]]:
    with open(path, encoding="utf-8") as f:
        text = f.read()

    errors: list[str] = []
    warnings: list[str] = []

    for name, pattern in REQUIRED_CHECKS:
        if not re.search(pattern, text):
            errors.append(f"MISSING: {name}")

    for name, pattern in FORBIDDEN_CHECKS:
        if re.search(pattern, text):
            errors.append(f"FORBIDDEN: {name}")

    _check_table_rules(text, errors, warnings)

    for name, pattern in OPTIONAL_WARNINGS:
        if not re.search(pattern, text):
            warnings.append(f"WARN: {name} not found (may be optional for module type)")

    n_constraints = count_constraints(text)
    if n_constraints < 5:
        errors.append(
            f"INSUFFICIENT: constraints found {n_constraints}, need >= 5 "
            "(\\item or 【主题】 format in 约束与实现要点)"
        )

    body = _extract_constraints_section(text) or ""
    if "无状态机" not in body and "状态机" not in body:
        errors.append(
            "MISSING: C1 must include 【无状态机】 constraint "
            "(prefer condition checks over FSM to avoid state lock)"
        )
    elif "无状态机" not in body and re.search(r"状态机", body):
        warnings.append(
            "WARN: constraints mention 状态机 but lack 【无状态机】; "
            "prefer explicit condition checks over FSM"
        )

    # Discourage dedicated FSM sections as default implementation guidance
    if re.search(r"\\section\{[^}]*状态机[^}]*\}", text):
        warnings.append(
            "WARN: dedicated 状态机 section found; prefer Step + condition "
            "tables unless standard forces a mode set"
        )

    if "技术文档" not in text and "技术文档" not in path:
        warnings.append("WARN: filename or content may not identify as 技术文档")

    if re.search(r"\\part\{", text) and text.count("\\part{") < 2:
        warnings.append("WARN: expected 2 \\part{} (总览 + 工程解读)")

    return errors, warnings


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python validate_tech_doc.py <tech-doc.tex>", file=sys.stderr)
        return 2

    path = sys.argv[1]
    errors, warnings = validate(path)

    print(f"Validating tech doc: {path}")
    for w in warnings:
        print(f"  {w}")
    for e in errors:
        print(f"  {e}")

    if errors:
        print(f"FAILED: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1

    print(f"PASSED: {len(warnings)} warning(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
