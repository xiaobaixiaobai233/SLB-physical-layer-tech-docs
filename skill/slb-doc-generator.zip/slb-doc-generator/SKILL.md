---
name: slb-doc-generator
description: Generates SLB (星闪 NearLink) learning materials and AI-oriented technical documents from T/XS 10001-2025 spec sections. Use when user asks to generate SLB 学习资料 or 技术文档 for protocol sections 6.x.x.
---

# SLB 文档生成 Skill

## 职责

按已磨合的工作流程，从 T/XS 10001-2025 标准条文**按需生成两类 LaTeX 文档**：

| 输出 | 读者 | 目的 |
|------|------|------|
| **学习资料** | 初学者 / 团队成员 | 用类比、图示、学习要点框解释协议知识，建立直觉 |
| **技术文档** | 工程师 / AI 代码生成 | 结构化工程解读：边界、参数表、处理步骤、约束，供实现与 vibecoding |

两类文档**独立生成**，但共享同一标准来源与节号划分。技术文档生成后，AI 应配合 `nearlink-naming` skill（airMode=slb）进行代码生成。

## 实现取向硬约束（文档与后续代码通用）

生成技术文档、处理步骤、伪代码，以及据此 vibecode 时，**默认禁止用状态机做流程跳转**：

| 要求 | 说明 |
|------|------|
| **优先条件判断** | 用「当前事件 / 配置 / 标志位 / 计数器」等**显式条件**决定下一步（`if/else`、查表、优先级判断），不要维护 IDLE/WORK/DONE 等状态图跳转 |
| **避免状态锁死** | 状态机易因漏转移、异常路径未复位而卡死；条件驱动路径每步可独立进入/退出，失败直接报错或回退到调用方 |
| **文档怎么写** | §B5 用编号 Step + 触发条件表；§C1 须含一条 `【无状态机】：…`；**不要**新增「状态机」专节引导实现 |
| **例外** | 仅当标准条文**显式规定**状态/模式集合且无法改写成条件时，才用「模式枚举 + 条件」描述；仍禁止推荐复杂 FSM 跳转表作为默认实现 |

## 表格硬约束（学习资料与技术文档通用）

生成/修订任何 SLB LaTeX 文档时，表格须同时满足：

| 要求 | 说明 |
|------|------|
| **可跨页** | **禁止** `\begin{table}` 浮动体；一律用 `\begin{longtable}`，避免整表被挤到下一页留白 |
| **顺序编号** | **每个** `longtable` 必须有 `\caption{…}`，由 LaTeX 按正文出现顺序自动编为表 1、表 2、… |
| **禁止双重编号** | `\caption` 内**不要**手写「表 1」「表 5」等（含标准表号）；否则 PDF 出现「表 8: 表 2 …」 |
| **交叉引用** | 用 `\caption{标题\label{tab:…}}` + 正文 `表~\ref{tab:…}`，勿在正文手写表号 |
| **宏包** | 导言区须含 `\usepackage{longtable}`（及按需 `array`） |

细则见 [references/tech-doc-style-guide.md](references/tech-doc-style-guide.md) §6.1；校验脚本会检查浮动 `table`、缺 caption、caption 手写「表 N」。

## 触发场景

- 用户指定协议节号（如 6.2.4、6.5.6、6.6.2），要求生成学习资料或技术文档
- 用户提供标准摘录 / PDF 段落，要求按工作区规范分块产出文档
- 用户要求「按之前的流程」「像 6.2.3 那样」写 SLB 文档
- 用户要求更新、补全某节缺失的文档类型（如 6.2.6 仅有学习资料缺技术文档）
- 用户要求编译、校验或打包 `.tex` + `.pdf` 交付物

**不触发**：无人机通信、MAVLink、SLE（非 SLB）等非 SLB 文档任务。

## 执行步骤

### Phase 0：收集输入

向用户确认或从上下文提取：

```
- 目标节号：6.x.x（可合并相邻节，如 6.2.7–6.2.10）
- 标准标题与条文（粘贴文本、摘录文件或 PDF 段落）
- 输出类型：学习资料 / 技术文档 / 两者
- 输出路径：YYYYMMDD-<节号>-<中文主题>/
- 文档日期：YYYY 年 M 月 D 日
- 封面层名：物理层 / 通用功能 / 位置测量流程 等
- 关键词：3–5 个（技术文档封面用）
- 适用读者前置知识（学习资料用，如「已掌握 6.2.2 帧结构」）
```

若标准条文过长，先写入工作目录的 `spec_extract.txt` 再生成。

### Phase 1：规划文档粒度

1. **默认**：一个 `6.x.x` → 一份学习资料 + 一份技术文档
2. **可合并**：内容构成单一工程模块时合并（如 6.5.1–6.5.3、6.2.7–6.2.10、6.3.1–6.3.3）
3. 判定模块类型 → 见 [references/module-type-guide.md](references/module-type-guide.md)
4. 确定文件命名 → 见 [references/naming-conventions.md](references/naming-conventions.md)

### Phase 2：生成学习资料（若需要）

1. 复制 [assets/learning-material-template.tex](assets/learning-material-template.tex) 为输出文件
2. 按 [references/learning-material-standards.md](references/learning-material-standards.md) 填写内容
3. 结构遵循标准子节号（`\section{6.x.x.y …}`）， pedagogical 顺序可调整
4. 必须包含：导读、推荐学习顺序、前置章节引用、`\learn{}` 或 keypoint 框、小结、灰色免责声明
5. **禁止**：`\part{}` 工程骨架、模块边界表、编号 Step 流水线（这些属于技术文档）

### Phase 3：生成技术文档（若需要）

1. 复制 [assets/tech-doc-template.tex](assets/tech-doc-template.tex) 为输出文件
2. **严格遵循** [references/tech-doc-style-guide.md](references/tech-doc-style-guide.md) 固定骨架
3. 执行顺序：
   - Step 1：判定模块类型
   - Step 2：填 Part 1 §1 子节划分表
   - Step 3：梳理上下游 → §2 + §A3 模块边界
   - Step 4：写 §A2 功能定义、§A4 流程角色
   - Step 5：按模块类型写 B 区（先 B1 关键参数表，再 B2 核心详解）
   - Step 6：写 C1 约束（≥5 条 `【主题】：` 格式；**必须含** `【无状态机】` 一条）
   - Step 7：写 C2 章节衔接
4. **禁止**：`\learn{}`、教学口吻、记忆口诀、大段标准原文粘贴；**禁止**默认用状态机描述实现跳转（见上文「实现取向硬约束」）

### Phase 4：编译与校验

```bash
# 编译（xelatex 两遍，清理中间文件）
python scripts/build_doc.py <path/to/document.tex>

# 校验
python scripts/validate_learning_doc.py <path/to/learning.tex>
python scripts/validate_tech_doc.py <path/to/tech-doc.tex>
```

校验通过后再交付。失败则修复后重跑。

### Phase 5：交付

最终仅保留 **`.tex` + `.pdf`**（删除 `.aux .log .out .toc .synctex.gz`）。

可选后续（不在本 Skill 核心范围，用户明确要求时再执行）：
- 归档副本到 `整合文档/<章>/<节号>（YYYYMMDD）.tex`
- C 参考实现（配合 nearlink-naming）
- PPT（outline.md → deck_spec.json）

## 输出标准

### 学习资料

| 项 | 标准 |
|----|------|
| 格式 | LaTeX `ctexart` + xelatex |
| 文件名 | 见 naming-conventions |
| 标题 | 含 `—— 学习资料 ——` 或「学习资料」标识 |
| 结构 | 标准子节号 section，无 `\part{}` |
| 教学元素 | ≥3 处 `\learn{}` 或 keypoint；≥1 类比或口诀；≥1 直观理解表 |
| 公式 | 完整标准公式 + 文字解释 |
| 表格 | `longtable` 可跨页；每表 `\caption`；顺序自动编号；caption 勿写「表 N」 |
| 免责 | 灰色页脚「仅供理解参考，以正式标准为准」 |
| 禁止 | 工程 Step 流水线、模块边界表、`\part{}` 骨架；浮动 `\begin{table}` |

### 技术文档

| 项 | 标准 |
|----|------|
| 格式 | LaTeX `ctexart` + xelatex |
| 文件名 | `SLB<层名><节号><节名简称>技术文档.tex` |
| 结构 | Part 1 总览 + Part 2 工程解读；A1–A4 与 C1–C3 固定节齐全 |
| 参数 | B1 提炼表，每条附标准子节指针，禁止原文粘贴 |
| 表格 | `longtable` 可跨页；每表 `\caption`；按出现顺序连续编号；禁止 caption 手写「表 N」 |
| 步骤 | 适用模块含编号 Step 1…N |
| 约束 | C1 ≥5 条，格式 `【主题】：…`；须含 `【无状态机】` |
| 上下文 | 每项功能/信号/控制说明所在 PIB/符号/链路/流程阶段 |
| 流程实现 | 用 Step + 条件判断，不用 FSM 跳转表 |
| 禁止 | `\learn{}`、教学口吻、标准复印件；默认状态机实现；浮动 `\begin{table}` |

完整检查清单 → [references/quality-checklist.md](references/quality-checklist.md)

## 参考资源

| 文件 | 内容 |
|------|------|
| [references/tech-doc-style-guide.md](references/tech-doc-style-guide.md) | 技术文档写作风格提示（完整版） |
| [references/learning-material-standards.md](references/learning-material-standards.md) | 学习资料格式与内容标准 |
| [references/naming-conventions.md](references/naming-conventions.md) | 文件/文件夹命名规范 |
| [references/module-type-guide.md](references/module-type-guide.md) | 模块类型判定与 B 区选用 |
| [references/quality-checklist.md](references/quality-checklist.md) | 交付前质量检查清单 |

## 工作区示例（生成前可读作参考，非硬依赖）

- 学习资料：`6.2-120khz子载波间隔系统/20260622-6.2.1-一般描述/星闪120kHz物理层一般概述-学习资料.tex`
- 技术文档：`6.2-120khz子载波间隔系统/20260622-6.2.1-一般描述/SLB物理层6.2.1一般描述技术文档.tex`
- 带 `\learn{}` 范例：`6.6-位置测量流程/6.6.1-一般概述/星闪SLB物理层6.6.1位置测量流程一般概述-学习资料.tex`

## 快速提示词模板

**仅学习资料：**
```
Use slb-doc-generator skill. Generate 学习资料 only.
Section: 6.x.x「节名」
Standard text: <paste>
Output: <folder path>
Prerequisites: <已掌握章节>
```

**仅技术文档：**
```
Use slb-doc-generator skill. Generate 技术文档 only.
Section: 6.x.x「节名」
Standard text: <paste>
Output: <folder path>
Layer: 物理层
Keywords: kw1 • kw2 • kw3
Date: YYYY 年 M 月 D 日
```

**两者：**
```
Use slb-doc-generator skill. Generate both 学习资料 and 技术文档.
Section: 6.x.x「节名」
Standard text: <paste or spec_extract.txt path>
Output: <folder path>
```
