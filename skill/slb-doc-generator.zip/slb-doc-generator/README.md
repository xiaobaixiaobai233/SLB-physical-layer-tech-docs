# slb-doc-generator

An Agent Skill for generating **SLB (星闪 / NearLink Synchronous Low-latency Broadband)** protocol documentation from **T/XS 10001-2025** standard text.

This skill codifies a production workflow used to split each protocol section into two complementary LaTeX deliverables:

| Output | Chinese name | Audience | Purpose |
|--------|--------------|----------|---------|
| **Learning material** | 学习资料 | Beginners, team onboarding | Teach concepts with analogies, intuition, and highlighted takeaways |
| **Technical document** | 技术文档 | Engineers, AI code generation | Structured engineering reference: boundaries, parameter tables, processing steps, constraints |

Both documents share the same standard source and section numbering, but are **generated independently** with different structure and tone.

---

## Table of Contents

- [Background](#background)
- [What This Skill Does](#what-this-skill-does)
- [Installation](#installation)
- [Directory Layout](#directory-layout)
- [Prerequisites](#prerequisites)
- [Document Types in Detail](#document-types-in-detail)
- [End-to-End Workflow](#end-to-end-workflow)
- [Usage](#usage)
- [File and Folder Naming](#file-and-folder-naming)
- [Scripts Reference](#scripts-reference)
- [Quality Gates](#quality-gates)
- [Reference Documents](#reference-documents)
- [Related Skills](#related-skills)
- [Troubleshooting](#troubleshooting)
- [Out of Scope](#out-of-scope)

---

## Background

The SLB physical-layer documentation pipeline was developed iteratively across workspace sections such as:

- `6.2-120khz子载波间隔系统` (§6.2.1–6.2.10)
- `6.5-物理层通用功能` (§6.5.x common PHY functions)
- `6.6-位置测量流程` (§6.6.x positioning / measurement)

Each section typically produces:

1. A **learning material** (`.tex` + `.pdf`) — human-readable teaching notes
2. A **technical document** (`.tex` + `.pdf`) — implementation-oriented reference for engineers and AI-assisted coding

The canonical style authority for technical documents is the workspace file `SLB物理层技术文档写作风格提示.txt` (v2026-07-06), fully reproduced in `references/tech-doc-style-guide.md`.

---

## What This Skill Does

When invoked, the agent should:

1. Accept a target protocol section (e.g. `6.2.4`, `6.5.6`, `6.6.2`) and standard text
2. Decide document granularity (single section vs. merged adjacent sections)
3. Classify the module type (signal, control, structure, codec, etc.)
4. Generate one or both document types from the provided templates
5. Compile with `xelatex` (two passes) and validate structure
6. Deliver **only** `.tex` + `.pdf` (auxiliary files removed)

The skill does **not** automatically generate C reference code or PPT decks — those are optional follow-ups when explicitly requested.

### Implementation preference (hard rule)

For technical documents and subsequent vibecoding guided by them:

- **Do not** default to finite-state machines (FSM) for control-flow jumps.
- **Prefer** explicit condition checks on events, flags, counters, and configuration fields (`if/else`, lookup tables).
- Reason: FSMs often lock up when a transition or exception path is missing.
- C1 constraints **must** include `【无状态机】`. Dedicated “状态机” sections are discouraged unless the standard forces a mode set (still describe as mode + conditions, not FSM jump tables).

---

## Installation

### Cursor (recommended)

1. Unzip `slb-doc-generator.zip`
2. Copy the entire `slb-doc-generator/` folder to one of:

   | Scope | Path |
   |-------|------|
   | Personal (all projects) | `~/.cursor/skills/slb-doc-generator/` |
   | Project (single repo) | `.cursor/skills/slb-doc-generator/` |

   On Windows, personal skills live at:

   ```
   C:\Users\<YOU>\.cursor\skills\slb-doc-generator\
   ```

3. Restart Cursor, or invoke directly in chat:

   ```
   Use slb-doc-generator skill.
   ```

### Claude Code

Copy to:

```
~/.claude/skills/slb-doc-generator/
```

### Verify installation

After copying, confirm these files exist:

```
slb-doc-generator/SKILL.md
slb-doc-generator/assets/learning-material-template.tex
slb-doc-generator/assets/tech-doc-template.tex
slb-doc-generator/scripts/build_doc.py
```

---

## Directory Layout

```
slb-doc-generator/
├── SKILL.md                              # Agent entry point: triggers, steps, output standards
├── README.md                             # This file — human-readable guide
│
├── references/                           # Confirmed format and content standards
│   ├── tech-doc-style-guide.md           # Full technical doc style guide (from 风格提示.txt)
│   ├── learning-material-standards.md    # Learning material format rules
│   ├── naming-conventions.md             # File/folder naming patterns
│   ├── module-type-guide.md              # Module type classification + Part 2 section selection
│   └── quality-checklist.md              # Pre-delivery checklist
│
├── assets/                               # Reusable LaTeX templates
│   ├── learning-material-template.tex    # Learning material skeleton (<<PLACEHOLDER>> markers)
│   └── tech-doc-template.tex             # Technical document skeleton (two-Part fixed structure)
│
└── scripts/                              # Automation utilities
    ├── build_doc.py                      # xelatex ×2, optional aux cleanup
    ├── validate_learning_doc.py          # Structural validation for learning materials
    ├── validate_tech_doc.py              # Structural validation for technical documents
    └── scaffold_workpackage.py           # Create a dated work-package folder from templates
```

**Progressive disclosure:** The agent reads `SKILL.md` first, then pulls in reference files only when needed. You do not need to paste the full style guide into every prompt.

---

## Prerequisites

### Required for PDF output

| Tool | Notes |
|------|-------|
| **XeLaTeX** | TeX Live or MiKTeX with `ctex` package support |
| **ctexart** | Document class used by all templates |

Typical compile command (also wrapped by `build_doc.py`):

```bash
xelatex -interaction=nonstopmode document.tex   # run twice
```

### Required for scripts

| Tool | Version |
|------|---------|
| **Python** | 3.8+ |

No third-party Python packages are required for build/validate/scaffold scripts.

---

## Document Types in Detail

### Learning Material (学习资料)

**Goal:** Help a reader *understand* the standard before reading implementation docs or writing code.

| Aspect | Standard |
|--------|----------|
| Tone | Pedagogical — analogies, mnemonics, recommended reading order |
| Structure | Free-form `\section{}` following spec numbering (`6.x.x.y`); **no** `\part{}` engineering skeleton |
| Highlights | `\learn{}` macro or `keypoint` environment (≥3 recommended) |
| Tables | `longtable` (page-breakable); every table has `\caption`; sequential auto-numbering; **do not** put handwritten 「表 N」 in caption |
| Formulas | Full standard formulas **with** symbol explanations |
| Footer | Gray disclaimer: for understanding only; formal standard is authoritative |
| Forbidden | Module boundary tables, numbered Step 1…N implementation pipelines, `\part{总览}`, floating `\begin{table}` |

**Example filename:** `星闪120kHz物理层6.2.3物理层信号-学习资料.tex`

### Technical Document (技术文档)

**Goal:** Give engineers and AI enough structure to *implement* and *integrate* the module.

| Aspect | Standard |
|--------|----------|
| Tone | Engineering — tables and numbered steps; no teaching voice |
| Structure | Fixed two-Part skeleton (see below) |
| Parameters | Extracted summary tables with standard clause pointers — **never** paste standard verbatim |
| Steps | Numbered Step 1…N for TX/RX where applicable |
| Constraints | ≥5 items under `约束与实现要点`; **must include `【无状态机】`** |
| Tables | `longtable` only (no floating `table`); every table captioned; sequential auto-numbering; no handwritten 「表 N」 in `\caption` |
| Footer | Gray disclaimer: for implementation reference; field-level definitions follow the standard |
| Forbidden | `\learn{}`, mnemonics, "intuitive understanding" headers, large standard excerpts, floating `\begin{table}` |

**Fixed skeleton:**

```
Part 1 — Overview
  §1  Document scope and module breakdown table
  §2  Relationships with related sections
  §3  (Optional) System positioning / pipeline / basic parameters

Part 2 — Engineering interpretation
  A1  Protocol section mapping
  A2  Functional definition (3–5 numbered items)
  A3  Module boundaries (upstream / downstream / out-of-scope)
  A4  Role in SLB communication flow
  B*  Core engineering content (selected by module type)
  C1  Constraints and implementation notes (≥5)
  C2  Cross-section links
  C3  Footer disclaimer
```

**Example filename:** `SLB物理层6.2.4物理层控制信息技术文档.tex`

### Side-by-side comparison

| | Learning Material | Technical Document |
|---|-------------------|-------------------|
| Primary reader | Human beginner | Engineer / AI |
| LaTeX class | `ctexart` | `ctexart` |
| Top-level structure | Spec-numbered sections | `\part{总览}` + `\part{工程解读}` |
| Teaching elements | `\learn{}`, analogies, mnemonics | Parameter tables, Step pipelines |
| Module boundaries | Not included | Required (upstream/downstream tables) |
| Use before coding | Yes — read first | Yes — use as implementation spec |
| Paired with | Same-section tech doc | Same-section learning material + `nearlink-naming` for code |

---

## End-to-End Workflow

```
T/XS 10001-2025 standard text
        │
        ├─► spec_extract.txt (optional working copy)
        │
        ├── Learning material .tex
        │       └─► xelatex ×2 ─► .pdf
        │
        └── Technical document .tex
                └─► xelatex ×2 ─► .pdf
                        └─► (optional) AI code generation with nearlink-naming
```

### Agent phases (summary)

| Phase | Action |
|-------|--------|
| **0 — Input** | Confirm section ID, standard text, output type, folder path, date, keywords, prerequisites |
| **1 — Plan** | Decide granularity (single vs. merged sections), module type, filenames |
| **2 — Learning** | Fill learning template per `learning-material-standards.md` |
| **3 — Technical** | Fill tech template per `tech-doc-style-guide.md` fixed skeleton |
| **4 — Build** | Run validate → build → validate again if needed |
| **5 — Deliver** | Keep only `.tex` + `.pdf` |

### When to merge adjacent sections

Merge into one document pair when sections form a single engineering module:

| Merged range | Rationale |
|--------------|-----------|
| 6.2.7–6.2.10 | Signal processing / sync / baseband / RF chain |
| 6.5.1–6.5.3 | CRC + Gold sequence + QPSK reference |
| 6.5.4–6.5.5 | Power control + measurement quantities |
| 6.5.7–6.5.9 | Scrambling / waveform / sequences |
| 6.3.1–6.3.3 | Flexible bandwidth |

Default remains **one `6.x.x` → one learning + one technical doc**.

---

## Usage

### Invoke via Agent (recommended)

**Both document types:**

```
Use slb-doc-generator skill. Generate both 学习资料 and 技术文档.
Section: 6.2.5「物理层数据信息」
Standard text: <paste T/XS 10001-2025 clause text>
Output: ./20260710-6.2.5-物理层数据信息
Layer: 物理层
Keywords: TB pipeline • MCS • resource mapping
Date: 2026 年 7 月 10 日
Prerequisites: 已掌握 6.2.2 帧结构、6.2.4 控制信息
```

**Learning material only:**

```
Use slb-doc-generator skill. Generate 学习资料 only.
Section: 6.2.6「信道编码」
Standard text: <paste or path to spec_extract.txt>
Output: ./20260710-6.2.6-信道编码
```

**Technical document only:**

```
Use slb-doc-generator skill. Generate 技术文档 only.
Section: 6.2.4「物理层控制信息」
Standard text: <paste>
Output: ./20260710-6.2.4-物理层控制信号
Layer: 物理层
Keywords: SAB • RAB • GCI • blind detection
Date: 2026 年 7 月 10 日
```

### Scaffold a work package manually

Creates a dated folder, copies templates, adds `spec_extract.txt` and `README.md`:

```bash
python scripts/scaffold_workpackage.py \
  --section 6.2.5 \
  --title 物理层数据信息 \
  --output ./20260710-6.2.5-物理层数据信息 \
  --both
```

Options:

| Flag | Description |
|------|-------------|
| `--both` | Generate both templates (default if no `--learning` / `--tech`) |
| `--learning` | Learning material template only |
| `--tech` | Technical document template only |
| `--layer` | Cover layer name (default: `物理层`) |
| `--prerequisites` | Reader prerequisites for learning material |

### Validate before building

```bash
# Learning material
python scripts/validate_learning_doc.py path/to/星闪120kHz物理层6.2.3物理层信号-学习资料.tex

# Technical document
python scripts/validate_tech_doc.py path/to/SLB物理层6.2.4物理层控制信息技术文档.tex
```

Exit code `0` = passed; non-zero = fix reported issues and re-run.

### Build PDF

```bash
python scripts/build_doc.py path/to/document.tex
```

This runs `xelatex` twice and removes `.aux`, `.log`, `.out`, `.toc`, etc. Use `--keep-aux` to retain auxiliary files for debugging.

---

## File and Folder Naming

### Work-package folder

```
YYYYMMDD-<section>-<topic>/
```

Example: `20260703-6.2.4-物理层控制信号`

### Learning material filenames

| Domain | Pattern |
|--------|---------|
| §6.2 (120 kHz system) | `星闪120kHz物理层<节号><节名>-学习资料.tex` |
| §6.1 / §6.3 / §6.6 | `星闪SLB物理层<节号><节名>-学习资料.tex` |
| §6.5 (common functions) | `SLB_<节号>_<主题>_学习资料.tex` |

### Technical document filenames

```
SLB物理层<节号><节名简称>技术文档.tex
```

Merged sections example: `SLB物理层6.2.7-10信号处理同步生成与调制技术文档.tex`

### Auxiliary files

| File | Purpose |
|------|---------|
| `spec_extract.txt` | Working copy of standard text for generation |
| `_sec_<id>.txt` | Section-specific extract (e.g. `_sec_626123.txt`) |

Full rules: `references/naming-conventions.md`

---

## Scripts Reference

### `build_doc.py`

```bash
python scripts/build_doc.py <path/to/document.tex> [--keep-aux]
```

- Runs `xelatex -interaction=nonstopmode` twice
- Prints PDF path and size
- Cleans auxiliary files unless `--keep-aux`

### `validate_learning_doc.py`

Checks for:

- `% !TEX program = xelatex` header
- "学习资料" marker in title
- T/XS 10001-2025 / 20250326 version reference
- Disclaimer footer
- Absence of technical-doc skeleton (`\part{总览}`, module boundaries, Step pipelines)
- Presence of `\learn{}` or `keypoint` (warns if <3)

### `validate_tech_doc.py`

Checks for:

- Two-Part structure (`\part{总览}`, fixed A/C sections)
- Required sections: protocol mapping, functional definition, module boundaries, constraints, cross-links
- ≥5 constraint items (flexible: `\item` list or `【主题】` markers in `约束与实现要点`)
- Absence of learning-only elements (`\learn{}`, mnemonics, "直观理解")
- T/XS standard reference

Some warnings (e.g. missing "处理步骤") are expected for index/classification module types.

### `scaffold_workpackage.py`

Bootstraps a new dated folder with templates, `spec_extract.txt`, and a local `README.md`. Does not fill content — use the agent or edit manually after scaffolding.

---

## Quality Gates

Before delivery, verify against `references/quality-checklist.md`. Key automatic checks:

| Check | Learning | Technical |
|-------|----------|-----------|
| xelatex compiles (×2) | ✓ | ✓ |
| Correct document type markers | ✓ | ✓ |
| No cross-type contamination | ✓ | ✓ |
| Required structural sections | ✓ | ✓ |
| Tables = `longtable` + `\caption` (no floating `table`, no handwritten 「表 N」) | ✓ | ✓ |
| ≥3 learning highlights | recommended | N/A |
| ≥5 constraints + `【无状态机】` | N/A | ✓ |
| Deliverables = `.tex` + `.pdf` only | ✓ | ✓ |

---

## Reference Documents

| File | Contents |
|------|----------|
| `references/tech-doc-style-guide.md` | Complete technical writing standard: positioning, LaTeX setup, fixed skeleton, parameter extraction rules, section-specific emphasis |
| `references/learning-material-standards.md` | Learning doc tone, required sections, `\learn{}` usage, forbidden elements |
| `references/naming-conventions.md` | Folder and file naming across §6.1–6.6 |
| `references/module-type-guide.md` | How to classify a section and which Part 2 B-sections to write |
| `references/quality-checklist.md` | Full pre-delivery checklist with `[auto]` vs manual items |

---

## Related Skills

| Skill | When to use |
|-------|-------------|
| **`nearlink-naming`** | After the technical document is ready and you want AI to generate SLB C/TS code. Set `airMode=slb`. |
| **`create-skill`** | If you need to extend or fork this skill for SLE or other NearLink modes. |

Typical code-generation prompt:

```
Use nearlink-naming skill for this task. airMode=slb.
Implement §6.2.3.1 FTS sequence generation per the technical document.
```

---

## Troubleshooting

### xelatex not found

Install TeX Live or MiKTeX and ensure `xelatex` is on `PATH`:

```bash
xelatex --version
```

### Missing ctex / Chinese font errors

Install the full `ctex` bundle. On MiKTeX, allow automatic package installation on first compile.

### Validation fails on constraints

Ensure the `约束与实现要点` section has ≥5 entries. Accepted formats:

```latex
\item \textbf{【Topic】}：constraint text
\item \textbf{Topic name}：constraint text
\item 【Topic】：constraint text
```

The validator counts both `\item` lines and `【…】` themed markers flexibly.

### Validation warns "processing steps not found"

Normal for **index/classification** modules (e.g. §6.2.1). See `references/module-type-guide.md` for which B-sections apply.

### Placeholders left in template

Search for `<<` in the `.tex` file before building. All `<<PLACEHOLDER>>` markers must be replaced.

### Agent generates wrong document type

Be explicit in the prompt: `Generate 学习资料 only` or `Generate 技术文档 only`. The two types must not share structure or tone.

---

## Out of Scope

This skill intentionally does **not** cover:

- **SLE** (Synchronous Low Energy) — different air interface; use separate conventions
- **Drone / MAVLink** documentation
- **PPT generation** (`outline.md` → `deck_spec.json`) — optional manual follow-up
- **C reference implementation** (`nearlink-*/slb/`) — optional; use technical doc + `nearlink-naming`
- **Consolidated archive** copies under `整合文档/` — optional post-delivery step

---

## Standard Reference

All documents cite:

> **T/XS 10001-2025**《星闪无线通信系统 接入层 同步低时延宽带空口 SLB 技术要求和测试方法》  
> Group standard version **20250326**

Field-level definitions and complete parameter tables always defer to the formal standard text.
