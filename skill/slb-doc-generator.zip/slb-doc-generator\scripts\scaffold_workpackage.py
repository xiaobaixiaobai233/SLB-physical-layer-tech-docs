#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Scaffold a new SLB document work package from templates.

Usage:
    python scaffold_workpackage.py \\
        --section 6.2.4 \\
        --title 物理层控制信息 \\
        --output ./20260710-6.2.4-物理层控制信号 \\
        [--both | --learning | --tech] \\
        [--layer 物理层] \\
        [--keywords "控制信息,SAB,PIB"] \\
        [--date "2026 年 7 月 10 日"] \\
        [--prerequisites "已掌握 6.2.2 帧结构、6.2.3 物理层信号"]
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from datetime import date


SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(SKILL_ROOT, "assets")


def learning_filename(section: str, title: str) -> str:
    if section.startswith("6.2"):
        return f"星闪120kHz物理层{section}{title}-学习资料.tex"
    if section.startswith("6.5"):
        safe = title.replace(" ", "_")
        return f"SLB_{section}_{safe}_学习资料.tex"
    return f"星闪SLB物理层{section}{title}-学习资料.tex"


def tech_filename(section: str, title: str) -> str:
    return f"SLB物理层{section}{title}技术文档.tex"


def scaffold(args: argparse.Namespace) -> int:
    out_dir = os.path.abspath(args.output)
    os.makedirs(out_dir, exist_ok=True)

    gen_learning = args.both or args.doc_type == "learning"
    gen_tech = args.both or args.doc_type == "tech"

    created: list[str] = []

    if gen_learning:
        src = os.path.join(ASSETS, "learning-material-template.tex")
        dst_name = learning_filename(args.section, args.title)
        dst = os.path.join(out_dir, dst_name)
        shutil.copy2(src, dst)
        created.append(dst)

    if gen_tech:
        src = os.path.join(ASSETS, "tech-doc-template.tex")
        dst_name = tech_filename(args.section, args.title)
        dst = os.path.join(out_dir, dst_name)
        shutil.copy2(src, dst)
        created.append(dst)

    readme = os.path.join(out_dir, "README.md")
    with open(readme, "w", encoding="utf-8") as f:
        f.write(f"# {args.section} {args.title}\n\n")
        f.write(f"- Created: {date.today().isoformat()}\n")
        f.write(f"- Standard: T/XS 10001-2025 (20250326)\n")
        f.write(f"- Layer: {args.layer}\n\n")
        f.write("## Files\n\n")
        for p in created:
            f.write(f"- `{os.path.basename(p)}`\n")
        f.write("\n## Next steps\n\n")
        f.write("1. Add standard text to `spec_extract.txt`\n")
        f.write("2. Fill template placeholders\n")
        f.write("3. Run `python scripts/validate_*.py` then `python scripts/build_doc.py`\n")

    spec_placeholder = os.path.join(out_dir, "spec_extract.txt")
    if not os.path.isfile(spec_placeholder):
        with open(spec_placeholder, "w", encoding="utf-8") as f:
            f.write(f"# T/XS 10001-2025 Section {args.section} {args.title}\n")
            f.write("# Paste standard text here\n")

    print(f"Work package: {out_dir}")
    for p in created:
        print(f"  Created: {p}")
    print(f"  Created: {readme}")
    print(f"  Created: {spec_placeholder}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Scaffold SLB document work package")
    parser.add_argument("--section", required=True, help="e.g. 6.2.4")
    parser.add_argument("--title", required=True, help="e.g. 物理层控制信息")
    parser.add_argument("--output", required=True, help="Output directory path")
    parser.add_argument("--both", action="store_true", help="Generate both doc types")
    parser.add_argument("--learning", dest="doc_type", action="store_const", const="learning")
    parser.add_argument("--tech", dest="doc_type", action="store_const", const="tech")
    parser.set_defaults(doc_type=None)
    parser.add_argument("--layer", default="物理层")
    parser.add_argument("--keywords", default="")
    parser.add_argument("--date", default=date.today().strftime("%Y 年 %m 月 %d 日"))
    parser.add_argument("--prerequisites", default="已掌握相关前置章节")
    args = parser.parse_args()

    if args.doc_type is None and not args.both:
        args.both = True

    return scaffold(args)


if __name__ == "__main__":
    sys.exit(main())
